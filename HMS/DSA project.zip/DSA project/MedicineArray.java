package Hospital_Management_System;
class MedicineArray {
    int max=10;
    int count=0;
    int[] medId=new int[max];
    String[] name=new String[max];
    int[] expiry=new int[max];
    int[] qty=new int[max];
    // Add medicine
    public void addMedicine(int id,String n,int exp,int q) {
        if(count==max) {
        System.out.println("Medicine storage full!");
            return;
        }
        medId[count]=id;
        name[count]=n;
        expiry[count]=exp;
        qty[count]=q;
        count++;
        System.out.println("Medicine added!");
    }
    // Display medicines
    public void displayMedicine() {
        if (count==0) {
            System.out.println("No medicines found!");
            return;
        }
        for(int i=0;i<count;i++) {
            System.out.println(
                "ID: " + medId[i] +
                " Name: " + name[i] +
                " Expiry: " + expiry[i] +
                " Qty: " + qty[i]
            );
        }
    }
    // Search medicine by name (Linear Search)
    public void searchMedicine(String key) {
        for (int i=0;i<count;i++) {
            if (name[i].equalsIgnoreCase(key)) {
                System.out.println("Medicine Found: "+name[i]+ 
                                   " Qty: " + qty[i]);
                return;
            }
        }
        System.out.println("Medicine not found!");
    }
    // Sort by expiry year
    public void sortByExpiry() {
        for (int i=0;i<count-1;i++) {
            for (int j=0;j<count-i-1;j++) {
                if (expiry[j]>expiry[j+1]) {
                    // swap expiry
                    int te=expiry[j];
                    expiry[j]=expiry[j+1];
                    expiry[j+1]=te;
                    // swap id
                    int ti=medId[j];
                    medId[j]=medId[j + 1];
                    medId[j+1]=ti;
                    // swap name
                    String ts=name[j];
                    name[j]=name[j+1];
                    name[j+1]=ts;
                    // swap qty
                    int tq=qty[j];
                    qty[j]=qty[j+1];
                    qty[j+1]=tq;
                }
            }
        }
        System.out.println("Medicines sorted by expiry");
    }
}