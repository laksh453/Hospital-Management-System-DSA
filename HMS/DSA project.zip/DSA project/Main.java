package Hospital_Management_System;
import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		        Scanner sc = new Scanner(System.in);  
		        PatientList list = new PatientList();
		        AppointmentQueue aq = new AppointmentQueue();
		        BillArray bills = new BillArray();
		        MedicineArray meds = new MedicineArray();
		        while (true) 
		        {
		            System.out.println("\n1 Add Patient");
		            System.out.println("2 View Patients");
		            System.out.println("3 Search Patient");
		            System.out.println("4 Delete Patient");
		            System.out.println("5 Book Appointment");
		            System.out.println("6 Process Appointment");
		            System.out.println("7 View Appointments");
		            System.out.println("8 Add Bill");
		            System.out.println("9 View Bills");
		            System.out.println("10 Sort Bills");
		            System.out.println("11 Add Medicine");
		            System.out.println("12 View Medicines");
		            System.out.println("13 Search Medicine");
		            System.out.println("14 Sort by Expiry");
		            System.out.println("15 Exit");		            
		            int choice = sc.nextInt();
		            switch (choice) {
		                case 1:
		                    System.out.print("Enter ID: ");
		                    int id = sc.nextInt();
		                    sc.nextLine();
		                    System.out.print("Enter Name: ");
		                    String name = sc.nextLine();
		                    System.out.print("Enter Age: ");
		                    int age = sc.nextInt();
		                    list.addPatient(id, name, age);
		                    break;
		                case 2:
		                    list.displayPatients();
		                    break;
		                case 3:
		                    System.out.print("Enter ID to search: ");
		                    list.searchPatient(sc.nextInt());
		                    break;
		                case 4:
		                    System.out.print("Enter ID to delete: ");
		                    list.deletePatient(sc.nextInt());
		                    break;
		                case 5:
		                    System.out.print("Enter patient ID for appointment: ");
		                    aq.enqueue(sc.nextInt());
		                    break;
		                case 6:
		                    aq.dequeue();
		                    break;
		                case 7:
		                    aq.displayQueue();
		                    break;		                    
		                case 8:
		                    System.out.print("Enter Bill ID: ");
		                    int bid = sc.nextInt();
		                    System.out.print("Enter Patient ID: ");
		                    int pid = sc.nextInt();
		                    System.out.print("Enter Amount: ");
		                    double amt = sc.nextDouble();
		                    bills.addBill(bid, pid, amt);
		                    break;
		                case 9:
		                    bills.displayBills();
		                    break;
		                case 10:
		                    bills.sortBills();
		                    break;		                    
		                case 11:
		                    System.out.print("Enter ID: ");
		                    int mid = sc.nextInt();
		                    sc.nextLine();
		                    System.out.print("Enter Name: ");
		                    String mname = sc.nextLine();
		                    System.out.print("Enter Expiry Year: ");
		                    int exp = sc.nextInt();
		                    System.out.print("Enter Quantity: ");
		                    int q = sc.nextInt();
		                    meds.addMedicine(mid, mname, exp, q);
		                    break;
		                case 12:
		                    meds.displayMedicine();
		                    break;
		                case 13:
		                    sc.nextLine();
		                    System.out.print("Enter medicine name: ");
		                    meds.searchMedicine(sc.nextLine());
		                    break;
		                case 14:
		                    meds.sortByExpiry();
		                    break;      
		                case 15:
		                	System.out.println("Exit");
		                default:
		                    System.out.println("Invalid Case");
		            }
		        }
		    }
}
