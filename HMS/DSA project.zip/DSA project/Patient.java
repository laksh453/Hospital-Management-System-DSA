package Hospital_Management_System;
class Patient {
    int id;
    String name;
    int age;
    Patient next;
    public Patient(int id,String name,int age) {
        this.id=id;
        this.name=name;
        this.age=age;
        this.next=null;
    }
}