package Hospital_Management_System;
class BillArray {
    int max=10;
    int count=0;
    int[] billId=new int[max];
    int[] patientId=new int[max];
    double[] amount=new double[max];
    // Add bill
    public void addBill(int bId, int pId, double amt) {
        if (count==max) {
            System.out.println("Bill storage full!");
            return;
        }
        billId[count]=bId;
        patientId[count]=pId;
        amount[count]=amt;
        count++;
        System.out.println("Bill added successfully!");
    }
    // Display bills
    public void displayBills() {
        if(count==0) 
        {
            System.out.println("No bills found!");
            return;
        }
        for (int i=0;i<count;i++) 
        {
            System.out.println(
                "Bill ID: "+billId[i]+" Patient ID: "+patientId[i] +
                " Amount: "+amount[i]);
        }
    }
    // Sort bills by amount (Bubble Sort – easy for college)
    public void sortBills() 
    {
        for(int i=0;i<count-1;i++) 
        {
            for(int j=0;j<count-i-1;j++) {
                if (amount[j]>amount[j+1]) {
                    // swap amount
                    double tempAmt=amount[j];
                    amount[j]=amount[j+1];
                    amount[j+1]=tempAmt;
                    // swap billId
                    int tempB=billId[j];
                    billId[j]=billId[j+1];
                    billId[j+1]=tempB;
                    // swap patientId
                    int tempP=patientId[j];
                    patientId[j]=patientId[j+1];
                    patientId[j+1]=tempP;
                }
            }
        }

        System.out.println("Bills sorted by amount!");
    }
}