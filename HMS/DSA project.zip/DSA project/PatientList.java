package Hospital_Management_System;
class PatientList {
    Patient head;
    // Insert patient at end
    public void addPatient(int id,String name,int age) {
        Patient newNode=new Patient(id,name,age);
        if (head==null) {
            head=newNode;
            return;
        }
        Patient temp=head;
        while(temp.next!=null) {
            temp=temp.next;
        }
        temp.next=newNode;
    }
    // Display patients
    public void displayPatients() {
        if (head==null) {
            System.out.println("No patients found!");
            return;
        }
        Patient temp=head;
        while (temp!=null) {
            System.out.println("ID: "+temp.id+ 
                               " Name: "+temp.name+ 
                               " Age: "+temp.age);
            temp=temp.next;
        }
    }
    // Search patient by ID
    public void searchPatient(int id) {
        Patient temp=head;

        while (temp!=null) {
            if (temp.id==id) {
                System.out.println("Patient Found:"+temp.name);
                return;
            }
            temp=temp.next;
        }
        System.out.println("Patient not found!");
    }
    // Delete patient by ID
    public void deletePatient(int id) {
        if(head==null) {
        	return;
        }
        if(head.id==id) {
            head=head.next;
            System.out.println("Patient deleted");
            return;
        }
        Patient temp=head;
        while (temp.next!=null && temp.next.id!=id) {
            temp=temp.next;
        }
        if(temp.next!=null) {
            temp.next=temp.next.next;
            System.out.println("Patient deleted");
        } else {
            System.out.println("Patient not found");
        }
    }
}