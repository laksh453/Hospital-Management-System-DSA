package Hospital_Management_System;
class AppointmentQueue 
{
    int front=-1,rear=-1;
    int size=5;   // you can increase
    int[] queue=new int[size];   // storing patient IDs
    // Add appointment
    public void enqueue(int id) {
        if(rear==size-1) 
        {
            System.out.println("Appointment queue is full!");
            return;
        }
        if(front==-1)
        {
        	front = 0;
        }
        queue[++rear]=id;
        System.out.println("Appointment booked for Patient ID:"+id);
    }
    // Process appointment
    public void dequeue() 
    {
        if(front==-1 || front>rear) 
        {
            System.out.println("No appointments!");
            return;
        }
        System.out.println("Patient treated with ID:"+queue[front]);
        front++;
    }
    // Display queue
    public void displayQueue() {
        if (front==-1 || front>rear) {
            System.out.println("Queue empty!");
            return;
        }
        System.out.print("Appointments: ");
        for (int i=front;i<=rear;i++) {
            System.out.print(queue[i]+" ");
        }
        System.out.println();
    }
}